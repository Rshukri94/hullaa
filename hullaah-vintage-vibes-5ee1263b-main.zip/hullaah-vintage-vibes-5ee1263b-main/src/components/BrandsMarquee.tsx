import { motion } from "framer-motion";

import chanelLogo from "@/assets/brands/chanel.png";
import louisvuittonLogo from "@/assets/brands/louisvuitton.png";
import gucciLogo from "@/assets/brands/gucci.png";
import hermesLogo from "@/assets/brands/hermes.png";
import pradaLogo from "@/assets/brands/prada.png";
import diorLogo from "@/assets/brands/dior.png";
import versaceLogo from "@/assets/brands/versace.png";
import rolexLogo from "@/assets/brands/rolex.png";
import cartierLogo from "@/assets/brands/cartier.png";
import burberryLogo from "@/assets/brands/burberry.png";

const brandLogos = [
  { name: "Chanel", logo: chanelLogo },
  { name: "Louis Vuitton", logo: louisvuittonLogo },
  { name: "Gucci", logo: gucciLogo },
  { name: "Hermès", logo: hermesLogo },
  { name: "Prada", logo: pradaLogo },
  { name: "Dior", logo: diorLogo },
  { name: "Versace", logo: versaceLogo },
  { name: "Rolex", logo: rolexLogo },
  { name: "Cartier", logo: cartierLogo },
  { name: "Burberry", logo: burberryLogo },
];

const BrandsMarquee = () => {
  return (
    <section className="py-16 bg-surface overflow-hidden">
      <div className="container mb-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-2">
            Featured Luxury Brands
          </h2>
          <p className="text-muted-foreground">
            Discover authentic vintage pieces from the world's most prestigious fashion houses
          </p>
        </motion.div>
      </div>

      <div className="relative mb-6">
        <div className="flex animate-marquee-left">
          {[...brandLogos, ...brandLogos].map((brand, index) => (
            <div key={`row1-${index}`} className="flex-shrink-0 mx-8 md:mx-12">
              <div className="w-44 h-24 md:w-56 md:h-28 flex items-center justify-center bg-background rounded-2xl border border-border p-4 hover:border-primary/30 hover:shadow-lg transition-all duration-300">
                <img 
                  src={brand.logo} 
                  alt={brand.name}
                  className="w-full h-full object-contain"
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="relative">
        <div className="flex animate-marquee-right">
          {[...brandLogos.slice(5), ...brandLogos.slice(0, 5), ...brandLogos.slice(5), ...brandLogos.slice(0, 5)].map((brand, index) => (
            <div key={`row2-${index}`} className="flex-shrink-0 mx-8 md:mx-12">
              <div className="w-44 h-24 md:w-56 md:h-28 flex items-center justify-center bg-background rounded-2xl border border-border p-4 hover:border-primary/30 hover:shadow-lg transition-all duration-300">
                <img 
                  src={brand.logo} 
                  alt={brand.name}
                  className="w-full h-full object-contain"
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BrandsMarquee;
