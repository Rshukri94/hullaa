import { motion } from "framer-motion";
import { FolderOpen, Camera, FileText, Rocket } from "lucide-react";

const steps = [
  {
    icon: FolderOpen,
    step: "01",
    title: "Choose category",
    description: "Select from clothing, watches, jewellery, and more vintage categories.",
  },
  {
    icon: Camera,
    step: "02",
    title: "Upload photos",
    description: "Take clear photos to showcase your item's unique character and condition.",
  },
  {
    icon: FileText,
    step: "03",
    title: "Add details",
    description: "Enter brand, condition, price, and your location for local buyers.",
  },
  {
    icon: Rocket,
    step: "04",
    title: "Post & get leads",
    description: "Publish your listing and start receiving inquiries from interested buyers.",
  },
];

const HowItWorks = () => {
  return (
    <section id="how-it-works" className="py-16 bg-background">
      <div className="container">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
            How It Works
          </h2>
          <p className="text-muted-foreground max-w-lg mx-auto">
            Start selling your vintage items in four simple steps
          </p>
        </div>

        {/* Steps */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <motion.div
              key={step.step}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="relative text-center"
            >
              {/* Connector Line (desktop) */}
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-10 left-[60%] w-[80%] h-px bg-border" />
              )}
              
              <div className="relative inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-surface border border-border mb-4 group-hover:border-primary transition-colors">
                <step.icon className="h-8 w-8 text-primary" />
                <span className="absolute -top-2 -right-2 w-7 h-7 bg-accent text-accent-foreground text-xs font-bold rounded-full flex items-center justify-center">
                  {step.step}
                </span>
              </div>
              
              <h3 className="font-semibold text-foreground text-lg mb-2">
                {step.title}
              </h3>
              <p className="text-sm text-muted-foreground max-w-xs mx-auto">
                {step.description}
              </p>
            </motion.div>
          ))}
        </div>

        {/* Note */}
        <p className="text-center text-xs text-muted-foreground mt-12">
          * Features may vary by location
        </p>
      </div>
    </section>
  );
};

export default HowItWorks;
