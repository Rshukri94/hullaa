import { Search } from "lucide-react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const quickChips = ["Watches", "Clothing", "Shoes", "Sunglasses", "Perfumes", "Jewellery"];

const HeroSection = () => {
  return (
    <section className="relative bg-surface overflow-hidden">
      
      <div className="container py-12 lg:py-20">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left Content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center lg:text-left"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-accent/20 text-accent-foreground rounded-full text-sm font-medium mb-6">
              <span className="w-2 h-2 bg-accent rounded-full animate-pulse"></span>
              Launching Soon in Saudi Arabia
            </div>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground leading-tight mb-4">
              Buy and sell vintage with{" "}
              <span className="text-primary">confidence</span>
            </h1>
            <p className="text-lg text-muted-foreground mb-8 max-w-lg mx-auto lg:mx-0">
              Discover timeless treasures from true vintage lovers. The marketplace where every piece tells a story.
            </p>

            {/* Search Bar - Demo Only */}
            <div className="relative mb-6">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                placeholder="Search brands, items, categories..."
                className="pl-12 h-14 text-base rounded-2xl border-border bg-background shadow-sm cursor-not-allowed opacity-75"
                disabled
              />
              <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs text-muted-foreground bg-muted px-2 py-1 rounded">
                Demo
              </span>
            </div>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row gap-3 mb-8">
              <Button size="lg" className="text-base px-8 rounded-xl">
                Get Early Access
              </Button>
              <Button variant="outline" size="lg" className="text-base px-8 rounded-xl">
                Learn More
              </Button>
            </div>

            {/* Quick Chips - Preview */}
            <div className="flex flex-wrap justify-center lg:justify-start gap-2">
              {quickChips.map((chip) => (
                <span
                  key={chip}
                  className="px-4 py-2 text-sm font-medium bg-background border border-border rounded-full text-muted-foreground"
                >
                  {chip}
                </span>
              ))}
            </div>
          </motion.div>

          {/* Right Content - Brand Showcase */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative"
          >
            <div className="bg-gradient-to-br from-primary/10 to-accent/10 rounded-3xl p-8 md:p-12">
              <div className="text-center mb-6">
                <span className="inline-block bg-accent text-accent-foreground px-4 py-1.5 rounded-full text-sm font-medium mb-4">
                  Coming Soon
                </span>
                <h3 className="text-xl md:text-2xl font-bold text-foreground mb-2">
                  Premium Vintage Marketplace
                </h3>
                <p className="text-muted-foreground text-sm">
                  Authentic pieces from world-renowned brands
                </p>
              </div>
              
              {/* Brand pills preview */}
              <div className="flex flex-wrap justify-center gap-2">
                {["CHANEL", "GUCCI", "HERMÈS", "LOUIS VUITTON", "DIOR", "PRADA", "CARTIER", "ROLEX"].map((brand, index) => (
                  <motion.span
                    key={brand}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.3, delay: 0.4 + index * 0.05 }}
                    className="px-4 py-2 bg-background border border-border rounded-full text-xs md:text-sm font-medium text-foreground"
                  >
                    {brand}
                  </motion.span>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
