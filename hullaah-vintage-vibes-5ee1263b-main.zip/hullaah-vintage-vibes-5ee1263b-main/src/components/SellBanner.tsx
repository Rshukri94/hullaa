import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Sparkles, Bell } from "lucide-react";

const SellBanner = () => {
  return (
    <section id="sell" className="py-16 bg-surface">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="relative overflow-hidden rounded-3xl bg-primary text-primary-foreground p-8 md:p-12 lg:p-16"
        >
          {/* Background Pattern */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-0 right-0 w-96 h-96 bg-accent rounded-full blur-3xl translate-x-1/2 -translate-y-1/2" />
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-primary-light rounded-full blur-3xl -translate-x-1/2 translate-y-1/2" />
          </div>
          
          <div className="relative z-10 max-w-2xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-accent/20 rounded-full text-sm font-medium mb-6">
              <Sparkles className="h-4 w-4 text-accent" />
              <span>Coming Soon</span>
            </div>
            
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
              Ready to sell?
            </h2>
            <p className="text-xl md:text-2xl font-semibold mb-2">
              Sell{" "}
              <span className="text-accent">6X faster</span>{" "}
              on HULLAA
            </p>
            <p className="text-primary-foreground/80 mb-8 max-w-md mx-auto">
              Join thousands of sellers reaching collectors across Saudi Arabia. Be the first to know when we launch.
            </p>
            
            <Button
              size="lg"
              className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold text-base px-8 rounded-xl shadow-lg"
            >
              <Bell className="mr-2 h-5 w-5" />
              Notify Me at Launch
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default SellBanner;
