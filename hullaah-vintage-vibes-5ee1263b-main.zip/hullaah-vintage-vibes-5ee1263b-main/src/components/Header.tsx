import { useState } from "react";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import HullaaLogo from "./HullaaLogo";

const navLinks = [
  { label: "Shop", href: "#trending" },
  { label: "Categories", href: "#categories" },
  { label: "Sell", href: "#sell" },
  { label: "How it works", href: "#how-it-works" },
  { label: "Safety", href: "#trust" },
  { label: "Support", href: "#footer" },
];

const Header = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 w-full bg-background/95 backdrop-blur-sm border-b border-border">
      <div className="container flex items-center justify-between h-16 lg:h-18">
        {/* Logo */}
        <a href="#" className="flex-shrink-0">
          <HullaaLogo size="md" />
        </a>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Desktop Actions */}
        <div className="hidden lg:flex items-center gap-3">
          <Button variant="outline" size="sm" disabled className="opacity-50">
            Sign in
          </Button>
          <Button size="sm">
            Get Early Access
          </Button>
        </div>

        {/* Mobile Menu Button */}
        <button
          className="lg:hidden p-2 -mr-2 text-foreground"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          aria-label="Toggle menu"
        >
          {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-background border-b border-border">
          <nav className="container py-4 flex flex-col gap-4">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors py-2"
                onClick={() => setMobileMenuOpen(false)}
              >
                {link.label}
              </a>
            ))}
            <div className="flex flex-col gap-2 pt-4 border-t border-border">
              <Button variant="outline" className="w-full" disabled>
                Sign in (Coming Soon)
              </Button>
              <Button className="w-full">
                Get Early Access
              </Button>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
