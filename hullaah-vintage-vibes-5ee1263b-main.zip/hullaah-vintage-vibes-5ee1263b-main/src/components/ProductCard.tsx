import { Heart, MapPin } from "lucide-react";
import { cn } from "@/lib/utils";

interface ProductCardProps {
  id: number;
  title: string;
  price: number;
  condition: string;
  location: string;
  image: string;
  size?: "sm" | "md" | "lg";
  className?: string;
}

const conditionColors: Record<string, string> = {
  "New": "bg-accent text-accent-foreground",
  "Like New": "bg-primary-light/20 text-primary",
  "Excellent": "bg-primary/10 text-primary",
  "Good": "bg-muted text-muted-foreground",
  "Used": "bg-muted text-muted-foreground",
};

const sizeClasses = {
  sm: "p-2",
  md: "p-3",
  lg: "p-4",
};

const ProductCard = ({
  title,
  price,
  condition,
  location,
  image,
  size = "md",
  className,
}: ProductCardProps) => {
  const conditionClass = conditionColors[condition] || conditionColors["Good"];
  
  return (
    <div
      className={cn(
        "group bg-card rounded-2xl border border-border overflow-hidden transition-all duration-300 hover:shadow-card-hover hover:border-primary/20 cursor-pointer",
        sizeClasses[size],
        className
      )}
    >
      {/* Image Container */}
      <div className="relative aspect-square rounded-xl overflow-hidden mb-3">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        {/* Favorite Button */}
        <button className="absolute top-2 right-2 p-2 bg-background/80 backdrop-blur-sm rounded-full opacity-0 group-hover:opacity-100 transition-opacity hover:bg-background">
          <Heart className="h-4 w-4 text-muted-foreground hover:text-destructive transition-colors" />
        </button>
        {/* Condition Badge */}
        <span className={cn("absolute bottom-2 left-2 px-2 py-1 text-xs font-medium rounded-full", conditionClass)}>
          {condition}
        </span>
      </div>

      {/* Content */}
      <div className="space-y-1">
        <h3 className="font-medium text-foreground text-sm line-clamp-1 group-hover:text-primary transition-colors">
          {title}
        </h3>
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <MapPin className="h-3 w-3" />
          <span className="truncate">{location}</span>
        </div>
        <p className="text-base font-bold text-foreground">
          SAR {price.toLocaleString()}
        </p>
      </div>
    </div>
  );
};

export default ProductCard;
