import { motion } from "framer-motion";

const brandCategories = [
  {
    category: "Luxury Fashion Houses",
    brands: ["CHANEL", "LOUIS VUITTON", "GUCCI", "HERMÈS", "PRADA", "DIOR"],
  },
  {
    category: "Italian Excellence",
    brands: ["VERSACE", "FENDI", "VALENTINO", "BOTTEGA VENETA", "BULGARI", "ARMANI"],
  },
  {
    category: "French Elegance",
    brands: ["SAINT LAURENT", "GIVENCHY", "CELINE", "BALENCIAGA", "BALMAIN", "LANVIN"],
  },
  {
    category: "Timepiece Masters",
    brands: ["ROLEX", "CARTIER", "OMEGA", "PATEK PHILIPPE", "TAG HEUER", "BREITLING"],
  },
];

const TrendingSection = () => {
  return (
    <section id="trending" className="py-16 bg-background">
      <div className="container">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-3">
            Brands You'll Find on HULLAA
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            From vintage Chanel to classic Rolex, discover authenticated pre-loved luxury from the world's most iconic brands
          </p>
        </motion.div>

        {/* Brand Categories Grid */}
        <div className="grid md:grid-cols-2 gap-6">
          {brandCategories.map((category, categoryIndex) => (
            <motion.div
              key={category.category}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: categoryIndex * 0.1 }}
              className="bg-surface border border-border rounded-2xl p-6"
            >
              <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
                <span className="w-2 h-2 bg-accent rounded-full"></span>
                {category.category}
              </h3>
              <div className="flex flex-wrap gap-2">
                {category.brands.map((brand, brandIndex) => (
                  <motion.span
                    key={brand}
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.3, delay: categoryIndex * 0.1 + brandIndex * 0.05 }}
                    className="px-4 py-2 bg-background border border-border rounded-full text-sm font-medium text-muted-foreground hover:text-foreground hover:border-primary/50 transition-colors cursor-default"
                  >
                    {brand}
                  </motion.span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom note */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
          className="text-center text-sm text-muted-foreground mt-8"
        >
          And many more premium brands coming to HULLAA marketplace
        </motion.p>
      </div>
    </section>
  );
};

export default TrendingSection;
