import { Shield, CreditCard, Star, Headphones } from "lucide-react";
import { motion } from "framer-motion";

const trustItems = [
  {
    icon: Shield,
    title: "Buyer Protection",
    description: "Shop with confidence knowing every purchase is protected",
  },
  {
    icon: CreditCard,
    title: "Secure Payments",
    description: "Safe transactions with encrypted payment processing",
  },
  {
    icon: Star,
    title: "Ratings & Reviews",
    description: "Verified reviews from our community of collectors",
  },
  {
    icon: Headphones,
    title: "Support & Disputes",
    description: "Dedicated team to help resolve any issues",
  },
];

const TrustStrip = () => {
  return (
    <section id="trust" className="py-12 bg-background border-y border-border">
      <div className="container">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          {trustItems.map((item, index) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="text-center group"
            >
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-primary/10 text-primary mb-3 group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                <item.icon className="h-6 w-6" />
              </div>
              <h3 className="font-semibold text-foreground mb-1">{item.title}</h3>
              <p className="text-sm text-muted-foreground">{item.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TrustStrip;
