import { motion } from "framer-motion";
import { ChevronRight } from "lucide-react";

const categories = [
  {
    name: "Clothing",
    image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=200&h=200&fit=crop",
    count: 2340,
  },
  {
    name: "Watches",
    image: "https://images.unsplash.com/photo-1524592094714-0f0654e20314?w=200&h=200&fit=crop",
    count: 856,
  },
  {
    name: "Shoes",
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=200&h=200&fit=crop",
    count: 1245,
  },
  {
    name: "Sunglasses",
    image: "https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=200&h=200&fit=crop",
    count: 432,
  },
  {
    name: "Perfumes",
    image: "https://images.unsplash.com/photo-1541643600914-78b084683601?w=200&h=200&fit=crop",
    count: 678,
  },
  {
    name: "Jewellery",
    image: "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=200&h=200&fit=crop",
    count: 921,
  },
];

const CategoriesSection = () => {
  return (
    <section id="categories" className="py-16 bg-surface">
      <div className="container">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl md:text-3xl font-bold text-foreground">
            Featured Categories
          </h2>
          <button className="flex items-center gap-1 text-sm font-medium text-primary hover:underline">
            View all <ChevronRight className="h-4 w-4" />
          </button>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-3 md:grid-cols-6 gap-4 md:gap-6">
          {categories.map((category, index) => (
            <motion.div
              key={category.name}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: index * 0.05 }}
              className="group cursor-pointer text-center"
            >
              <div className="relative aspect-square mb-3 rounded-2xl overflow-hidden bg-background border border-border group-hover:border-primary/30 transition-all">
                <img
                  src={category.image}
                  alt={category.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-foreground/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
              <h3 className="font-medium text-foreground text-sm md:text-base group-hover:text-primary transition-colors">
                {category.name}
              </h3>
              <p className="text-xs text-muted-foreground">
                {category.count.toLocaleString()} items
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CategoriesSection;
