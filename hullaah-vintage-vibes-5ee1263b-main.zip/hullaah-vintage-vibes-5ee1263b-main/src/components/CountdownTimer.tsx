import { useState, useEffect } from "react";
import { motion } from "framer-motion";

const LAUNCH_DATE = new Date(Date.now() + 35 * 24 * 60 * 60 * 1000);

interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

const CountdownTimer = () => {
  const [timeLeft, setTimeLeft] = useState<TimeLeft>({ days: 0, hours: 0, minutes: 0, seconds: 0 });

  useEffect(() => {
    const calculateTimeLeft = () => {
      const difference = LAUNCH_DATE.getTime() - new Date().getTime();
      
      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
          minutes: Math.floor((difference / 1000 / 60) % 60),
          seconds: Math.floor((difference / 1000) % 60),
        });
      }
    };

    calculateTimeLeft();
    const timer = setInterval(calculateTimeLeft, 1000);

    return () => clearInterval(timer);
  }, []);

  const timeBlocks = [
    { label: "Days", value: timeLeft.days },
    { label: "Hours", value: timeLeft.hours },
    { label: "Minutes", value: timeLeft.minutes },
    { label: "Seconds", value: timeLeft.seconds },
  ];

  return (
    <section className="py-16 bg-primary">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-primary-foreground mb-3">
            Launching Soon
          </h2>
          <p className="text-primary-foreground/80 mb-8 max-w-md mx-auto">
            The vintage marketplace you've been waiting for. Mark your calendar!
          </p>

          <div className="flex justify-center gap-3 md:gap-6 mb-8">
            {timeBlocks.map((block, index) => (
              <motion.div
                key={block.label}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                className="bg-white/10 backdrop-blur-sm rounded-2xl p-4 md:p-6 min-w-[70px] md:min-w-[100px]"
              >
                <div className="text-3xl md:text-5xl font-bold text-accent mb-1">
                  {String(block.value).padStart(2, "0")}
                </div>
                <div className="text-xs md:text-sm text-primary-foreground/70 uppercase tracking-wider">
                  {block.label}
                </div>
              </motion.div>
            ))}
          </div>

          <p className="text-sm text-primary-foreground/60">
            Expected Launch: May 2026
          </p>
        </motion.div>
      </div>
    </section>
  );
};

export default CountdownTimer;
