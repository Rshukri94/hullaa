import hullaaLogo from "@/assets/hullaa-logo.png";

interface HullaaLogoProps {
  className?: string;
  size?: "sm" | "md" | "lg";
}

const sizeClasses = {
  sm: "h-8",
  md: "h-10",
  lg: "h-14",
};

const HullaaLogo = ({ className = "", size = "md" }: HullaaLogoProps) => {
  return (
    <div className={`flex items-center ${className}`}>
      <img
        src={hullaaLogo}
        alt="HULLAA"
        className={`${sizeClasses[size]} w-auto object-contain`}
      />
    </div>
  );
};

export default HullaaLogo;
