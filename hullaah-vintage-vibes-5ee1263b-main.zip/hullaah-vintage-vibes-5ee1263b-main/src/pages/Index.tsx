/**
 * HULLAA Landing Page
 * 
 * A complete production-ready landing page for the HULLAA vintage marketplace.
 * 
 * HOW TO CUSTOMIZE:
 * 
 * 1. LOGO:
 *    - Replace the SVG in src/components/HullaaLogo.tsx with your actual logo asset
 *    - Or import an image: import logo from "@/assets/hullaa-logo.svg"
 * 
 * 2. COLORS (src/index.css):
 *    - Primary Teal: --primary (currently #3B6E70)
 *    - Accent Gold: --accent (currently #E4B870)
 *    - Light Teal: --primary-light (currently #74A3A0)
 *    - Adjust HSL values to match your brand
 * 
 * 3. IMAGES:
 *    - Product images are placeholder URLs - replace with real product images
 *    - Avatar images in testimonials - replace with real customer photos
 * 
 * 4. APP STORE LINKS (src/components/AppDownload.tsx):
 *    - Replace placeholder buttons with actual App Store / Google Play links
 *    - Replace QR code with actual QR code image
 * 
 * 5. PHONE MOCKUP:
 *    - Replace the placeholder screen with actual app screenshot
 * 
 * 6. CONTENT:
 *    - Update product listings with real items
 *    - Update testimonials with real customer reviews
 *    - Adjust pricing in SAR as needed
 */

import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import CountdownTimer from "@/components/CountdownTimer";
import BrandsMarquee from "@/components/BrandsMarquee";
import TrustStrip from "@/components/TrustStrip";
import CategoriesSection from "@/components/CategoriesSection";
import TrendingSection from "@/components/TrendingSection";
import SellBanner from "@/components/SellBanner";
import HowItWorks from "@/components/HowItWorks";
import TestimonialsSection from "@/components/TestimonialsSection";
import AppDownload from "@/components/AppDownload";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <HeroSection />
        <CountdownTimer />
        <BrandsMarquee />
        <TrustStrip />
        <CategoriesSection />
        <TrendingSection />
        <SellBanner />
        <HowItWorks />
        <TestimonialsSection />
        <AppDownload />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
